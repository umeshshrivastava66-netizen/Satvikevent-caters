import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Initialize Gemini API client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
} else {
  console.warn("GEMINI_API_KEY is not defined. AI Chat Box will run in fallback simulation mode.");
}

// In-Memory Database for Orders
interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  category: string;
}

interface Order {
  id: string;
  customerName: string;
  email: string;
  phone: string;
  address: string;
  items: OrderItem[];
  subtotal: number;
  deliveryCharge: number;
  tax: number;
  total: number;
  status: "Placed" | "Chef Preparing" | "Quality Check" | "Out for Delivery" | "Delivered";
  paymentMethod: "Card" | "UPI" | "NetBanking";
  paymentStatus: "Pending" | "Paid" | "Failed";
  transactionId?: string;
  createdAt: number; // Timestamp
  estimatedDeliveryAt: number; // Timestamp
  eventType?: string; // For catering orders
  guestCount?: number; // For catering orders
  specialInstructions?: string;
}

const orders: Map<string, Order> = new Map();

// Helper to transition orders automatically in background
const updateOrderStatus = (order: Order): Order["status"] => {
  const elapsedSeconds = (Date.now() - order.createdAt) / 1000;
  
  if (elapsedSeconds >= 120) {
    return "Delivered";
  } else if (elapsedSeconds >= 80) {
    return "Out for Delivery";
  } else if (elapsedSeconds >= 50) {
    return "Quality Check";
  } else if (elapsedSeconds >= 20) {
    return "Chef Preparing";
  }
  return "Placed";
};

// Menu Data
const MENU_ITEMS = [
  {
    id: "m1",
    name: "Maharaja Satvik Thali",
    description: "A divine royal thali with Basmati cumin rice, Panchamel Dal, Shahi Paneer, seasonal dry sabji, fresh butter rotis, cucumber raita, and premium Rasgulla. Prepared in pure A2 ghee.",
    price: 349,
    category: "Mains",
    image: "/src/assets/images/satvik_premium_thali_1783699387370.jpg",
    spicy: "Mild",
    rating: 4.9,
    reviews: 142
  },
  {
    id: "m_jain",
    name: "Special Shuddh Jain Thali",
    description: "Authentic Jain meal cooked strictly without root vegetables (no potato, onion, garlic, or ginger). Features Basmati Rice, Moong Dal, Shahi Paneer, Phulkas, and sweet Saffron Rasgulla.",
    price: 369,
    category: "Mains",
    image: "/src/assets/images/satvik_premium_thali_1783699387370.jpg",
    spicy: "Mild",
    rating: 5.0,
    reviews: 118
  },
  {
    id: "m2",
    name: "Satvik Paneer Tikka",
    description: "Premium fresh cottage cheese cubes marinated in a hung curd paste of Himalayan pink salt, organic turmeric, and hand-ground spices, grilled to perfection with bell peppers.",
    price: 249,
    category: "Starters",
    image: "/src/assets/images/satvik_paneer_tikka_1783699415993.jpg",
    spicy: "Medium",
    rating: 4.8,
    reviews: 98
  },
  {
    id: "m3",
    name: "Crispy Beetroot Kebabs",
    description: "Hearty croquettes made of grated beetroot, sweet potato, and aromatic green herbs, pan-seared with a light sesame crust. Served with cooling mint-coconut chutney.",
    price: 189,
    category: "Starters",
    image: "https://images.unsplash.com/photo-1601050690597-df056fb4ce78?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    spicy: "Mild",
    rating: 4.7,
    reviews: 76
  },
  {
    id: "m4",
    name: "Moong Dal Chilla Roll",
    description: "Thin crepes of stone-ground yellow moong dal stuffed with spiced grated paneer, fresh coriander, and steamed carrots. Light, nutritious, and incredibly wholesome.",
    price: 199,
    category: "Starters",
    image: "https://images.unsplash.com/photo-1626132647523-66f5bf380027?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    spicy: "Mild",
    rating: 4.6,
    reviews: 54
  },
  {
    id: "m5",
    name: "Kesar Shahi Paneer",
    description: "Tender paneer cubes simmered in a velvety sauce of pureed cashews, organic milk cream, and premium Kashmiri saffron strands. Elegant and rich without onion or garlic.",
    price: 279,
    category: "Mains",
    image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    spicy: "Medium",
    rating: 4.9,
    reviews: 110
  },
  {
    id: "m6",
    name: "Ayurvedic Panchamel Dal",
    description: "A nourishing mixture of five high-protein lentils tempered with pure organic A2 cow ghee, cumin seeds, fresh grated ginger, and healing digestive spices.",
    price: 189,
    category: "Mains",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    spicy: "Mild",
    rating: 4.8,
    reviews: 87
  },
  {
    id: "m7",
    name: "Saffron Rasgulla Plate",
    description: "Soft, spongy cottage cheese balls soaked in a delicate sugar syrup infused with pure organic saffron (kesar) and crushed green cardamom pods. Served chilled.",
    price: 129,
    category: "Sweets",
    image: "https://images.unsplash.com/photo-1587314168485-3236d6710814?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    spicy: "Sweet",
    rating: 4.9,
    reviews: 124
  },
  {
    id: "m8",
    name: "Golden Malpua with Rabdi",
    description: "Traditional Indian sweet pancakes made with milk solids and fennel seeds, fried in pure ghee, and dipped in saffron syrup. Topped with rich, slow-simmered rabdi.",
    price: 159,
    category: "Sweets",
    image: "https://images.unsplash.com/photo-1605197584547-c93ef12164bb?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    spicy: "Sweet",
    rating: 4.9,
    reviews: 95
  },
  {
    id: "cat1",
    name: "Satsang & Puja Buffet Package",
    description: "An elegant, traditional catering layout featuring a pure satvik menu with holy elements. Includes starter, primary mains, customized thali service, holy water stations, and clay-pot sweets. Minimum 30 guests.",
    price: 499, // Per plate
    category: "Catering",
    image: "/src/assets/images/indian_catering_event_1783699401228.jpg",
    spicy: "Customizable",
    rating: 5.0,
    reviews: 64
  },
  {
    id: "cat2",
    name: "Royal Satvik Wedding Feast",
    description: "A grand, lavish multi-course catering experience for weddings. Live counters for paper-thin dosas, stone-ground dal chilla, and hot jalebis with rabdi. 100% vegetarian, organic ingredients, cooked under ultra-sanitary conditions. Minimum 100 guests.",
    price: 799, // Per plate
    category: "Catering",
    image: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    spicy: "Customizable",
    rating: 4.9,
    reviews: 48
  }
];

// --- REST API ENDPOINTS ---

// Get Menu Items
app.get("/api/menu", (req, res) => {
  res.json(MENU_ITEMS);
});

// Place a New Order & Handle Payment Simulation
app.post("/api/checkout", (req, res) => {
  const {
    customerName,
    email,
    phone,
    address,
    items,
    paymentMethod,
    cardNumber, // simulated
    upiId, // simulated
    eventType,
    guestCount,
    specialInstructions
  } = req.body;

  if (!customerName || !email || !phone || !address || !items || !items.length || !paymentMethod) {
    return res.status(400).json({ error: "Missing required booking details." });
  }

  // Calculate receipt totals
  let subtotal = 0;
  items.forEach((item: any) => {
    subtotal += item.price * item.quantity;
  });

  // For catering packages, the item price is multiplied by guest count if it's a catering item
  const isCateringOrder = items.some((item: any) => item.category === "Catering");
  if (isCateringOrder && guestCount) {
    subtotal = 0;
    items.forEach((item: any) => {
      if (item.category === "Catering") {
        subtotal += item.price * guestCount;
      } else {
        subtotal += item.price * item.quantity;
      }
    });
  }

  const deliveryCharge = isCateringOrder ? 1500 : (subtotal > 500 ? 0 : 40); // Catering setups require higher freight/service charge
  const tax = Math.round(subtotal * 0.05); // 5% GST
  const total = subtotal + deliveryCharge + tax;

  // Generate random Order and Transaction ID
  const orderId = "SATVIK-" + Math.floor(100000 + Math.random() * 900000);
  const transactionId = "TXN-" + Math.random().toString(36).substr(2, 9).toUpperCase();

  const newOrder: Order = {
    id: orderId,
    customerName,
    email,
    phone,
    address,
    items,
    subtotal,
    deliveryCharge,
    tax,
    total,
    status: "Placed",
    paymentMethod,
    paymentStatus: "Paid", // Automatically mark as paid for our checkout demonstration
    transactionId,
    createdAt: Date.now(),
    estimatedDeliveryAt: Date.now() + (isCateringOrder ? 86400000 : 25 * 60 * 1000), // 24 Hours for catering, 25 mins for regular food
    eventType,
    guestCount,
    specialInstructions
  };

  orders.set(orderId, newOrder);

  res.status(201).json({
    message: "Order placed successfully!",
    order: newOrder
  });
});

// Get Order Tracking Information
app.get("/api/orders/:id", (req, res) => {
  const id = req.params.id.toUpperCase();
  const order = orders.get(id);

  if (!order) {
    return res.status(404).json({ error: "Order not found. Please double check the ID." });
  }

  // Dynamically update status based on elapsed time to ensure real-time progression in UI
  const currentStatus = updateOrderStatus(order);
  order.status = currentStatus;

  res.json(order);
});

// List all simulated orders (convenient for tracking / demonstration)
app.get("/api/orders", (req, res) => {
  const allOrders = Array.from(orders.values()).map(order => {
    order.status = updateOrderStatus(order);
    return order;
  });
  res.json(allOrders);
});

// Chat Bot Endpoint with Server-Side Gemini API Proxy
app.post("/api/chat", async (req, res) => {
  const { message, history } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Message is required." });
  }

  const systemPrompt = `You are "Sita", the intelligent Satvik Dining and Event Coordinator for "Satvik Events and Caters".
Your tone is deeply polite, humble, welcoming, warm, and professional, reflecting Ayurvedic hospitality (Atithi Devo Bhava).
You assist customers with:
1. Understanding the Satvik philosophy (strictly pure vegetarian, Special Shuddh Jain Thali available, prepared in hygienic pure ghee environments).
2. Explaining the menu options (Maharaja Satvik Thali, Special Shuddh Jain Thali, Paneer Tikka, Sweet Malpuas with Rabdi, and custom Satsang or Wedding feast buffets).
3. Specifying our hours of operation: We are open from 07:00 AM in the morning until 11:00 PM at night (07:00 AM to 11:00 PM) daily.
4. Helping calculate catering costs. (Standard Satsang Buffet is ₹499/plate, Royal Wedding Feast is ₹799/plate. Give quick mock calculations if they mention guests).
5. Answering booking and tracking queries (they can track food orders on the tracking page by entering their Order ID).
6. Giving organic ingredient details.

Keep responses concise, elegant, structured with bullet points where appropriate, and formatted beautifully in clean markdown. Avoid complex computer code or system jargon.`;

  // If Gemini is initialized, use it. Otherwise, use a smart local Ayurvedic rule-based responder.
  if (ai) {
    try {
      // Re-map history to Gemini format if needed, but a simple contents array works best
      const chatHistory = history ? history.map((h: any) => ({
        role: h.sender === "user" ? "user" : "model",
        parts: [{ text: h.text }]
      })) : [];

      // Create a chat instance
      const chatInstance = ai.chats.create({
        model: "gemini-3.5-flash",
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.7,
        }
      });

      // Restore history manually if any, or just send the contents
      if (chatHistory.length > 0) {
        // We can pass history directly when creating, but let's check correct SDK properties.
        // Let's use standard generateContent with history as part of the messages list
        const contents = [
          ...chatHistory,
          { role: "user", parts: [{ text: message }] }
        ];

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: contents,
          config: {
            systemInstruction: systemPrompt,
            temperature: 0.7,
          }
        });

        return res.json({ response: response.text });
      } else {
        const response = await chatInstance.sendMessage({ message: message });
        return res.json({ response: response.text });
      }
    } catch (error) {
      console.error("Gemini API Error:", error);
      return res.status(500).json({
        error: "Failed to connect to Satvik Assistant. Let me answer with local knowledge.",
        response: "Om Shanti. I am having a slight network connection issue, but let me assist you locally! We prepare purely Satvik meals (no onion, no garlic) in our central kitchen. You can order our Maharaja Thali, Paneer Tikka, or sweets right now from the menu, and track your active delivery status instantly! How can I serve you today?"
      });
    }
  } else {
    // Elegant local fallback responder
    const normalizedMsg = message.toLowerCase();
    let reply = "Om Shanti! Welcome to Satvik Events and Caters. I would be honored to assist you with our purely vegetarian (no onion, no garlic) culinary offerings. How may I serve you today?";

    if (normalizedMsg.includes("time") || normalizedMsg.includes("hour") || normalizedMsg.includes("open") || normalizedMsg.includes("close") || normalizedMsg.includes("schedule")) {
      reply = "Our sacred kitchen and delivery services operate **daily from 07:00 AM to 11:00 PM**. Feel free to place your orders or schedule custom catering packages within this window of time!";
    } else if (normalizedMsg.includes("menu") || normalizedMsg.includes("food") || normalizedMsg.includes("dish")) {
      reply = `We offer a beautiful selection of pure Satvik delights:
*   **Maharaja Satvik Thali** (₹349): A complete sacred meal featuring Basmati Rice, Panchamel Dal, Shahi Paneer, Butter Rotis, and dessert.
*   **Satvik Paneer Tikka** (₹249): Grilled fresh cottage cheese in healthy herbs and curd.
*   **Crispy Beetroot Kebabs** (₹189): Hearty croquettes with warm aromatic spices.
*   **Golden Malpua with Rabdi** (₹159): Divine traditional sweet pancake.

You can add any of these to your basket and complete a mock checkout to see our simulated real-time order tracker!`;
    } else if (normalizedMsg.includes("catering") || normalizedMsg.includes("event") || normalizedMsg.includes("wedding") || normalizedMsg.includes("party")) {
      reply = `We specialize in catering pure, spiritual food for divine gatherings:
*   **Satsang & Puja Buffet Package** (₹499 per plate): Ideal for housewarming, spiritual kirtans, and pujas. Includes catering buffet table setup and divine decorations.
*   **Royal Satvik Wedding Feast** (₹799 per plate): A lavish layout with interactive live counters (chillas, dosas) and rich main courses.

Would you like me to calculate a cost estimate for your guest count? Just type the number of guests!`;
    } else if (/\b\d+\b/.test(normalizedMsg)) {
      const match = normalizedMsg.match(/\b\d+\b/);
      const guests = parseInt(match[0]);
      if (guests >= 10) {
        reply = `Certainly! Here is a custom catering cost estimate for **${guests} guests**:
1.  **Satsang Buffet Package** (₹499/plate): ₹${guests * 499}
2.  **Royal Wedding Feast** (₹799/plate): ₹${guests * 799}

*All packages include full buffet setup, eco-friendly copper chaffing dish display, and expert hospitality staff. You can book directly using our Catering form on this website!*`;
      }
    } else if (normalizedMsg.includes("track") || normalizedMsg.includes("order status") || normalizedMsg.includes("where is my")) {
      reply = "To track your food order, please complete a purchase, copy your unique Order ID (e.g., `SATVIK-123456`), and enter it into the 'Track Order' tab above! You will see live, minute-by-minute status updates of your meal's preparation and delivery.";
    } else if (normalizedMsg.includes("onion") || normalizedMsg.includes("garlic") || normalizedMsg.includes("ayurved")) {
      reply = "True to Satvik principles, our kitchen is a strictly pure vegetarian temple. We completely exclude onion, garlic, mushrooms, and heavy heating spices. We prepare our meals using pure A2 cow ghee, rock salt (saindhav), and organic digestive herbs to promote peaceful energy, focus, and physical health.";
    }

    return res.json({ response: reply });
  }
});


// Add some default initial orders so the tracking tab isn't empty and demonstrates features immediately
const seedOrder1: Order = {
  id: "SATVIK-783612",
  customerName: "Aarav Mehta",
  email: "aarav.mehta@example.com",
  phone: "9876543210",
  address: "Apartment 4B, Shanti Enclave, New Delhi",
  items: [
    { id: "m1", name: "Maharaja Satvik Thali", price: 349, quantity: 2, category: "Mains" },
    { id: "m7", name: "Saffron Rasgulla Plate", price: 129, quantity: 1, category: "Sweets" }
  ],
  subtotal: 827,
  deliveryCharge: 0,
  tax: 41,
  total: 868,
  status: "Chef Preparing",
  paymentMethod: "UPI",
  paymentStatus: "Paid",
  transactionId: "TXN-SEED9812A",
  createdAt: Date.now() - 30 * 1000, // Created 30s ago, making it Preparation state
  estimatedDeliveryAt: Date.now() + 20 * 60 * 1000,
  specialInstructions: "Please deliver near the main temple gate."
};

const seedOrder2: Order = {
  id: "SATVIK-412953",
  customerName: "Sonia Sharma",
  email: "sonia@example.com",
  phone: "9123456789",
  address: "Villa 12, Lotus Greens, Noida",
  items: [
    { id: "cat1", name: "Satsang & Puja Buffet Package", price: 499, quantity: 1, category: "Catering" }
  ],
  subtotal: 14970, // 30 plates minimum
  deliveryCharge: 1500,
  tax: 749,
  total: 17219,
  status: "Placed",
  paymentMethod: "Card",
  paymentStatus: "Paid",
  transactionId: "TXN-SEED2410B",
  createdAt: Date.now() - 5 * 1000,
  estimatedDeliveryAt: Date.now() + 86400 * 1000,
  eventType: "Ganesh Puja",
  guestCount: 30,
  specialInstructions: "Aesthetic traditional flower decorations needed."
};

orders.set(seedOrder1.id, seedOrder1);
orders.set(seedOrder2.id, seedOrder2);


// --- SETUP VITE MIDDLEWARE OR STATIC SERVING ---
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting server in DEVELOPMENT mode with Vite Middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting server in PRODUCTION mode with static files...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Satvik Server successfully running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
